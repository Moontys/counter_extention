<?php

namespace Espo\Modules\Counter\Controllers;

class Counter extends \Espo\Core\Templates\Controllers\Base
{

}