<?php

namespace Espo\Modules\Counter\Jobs;

use Espo\Core\Job\Job;
use Espo\Core\Job\Job\Data;
use Espo\ORM\EntityManager;
use Espo\Modules\Counter\Entities\Counter;

class CounterJob implements Job
{
    private EntityManager $entityManager; // Atributes of Class

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function run(Data $data): void
    {
        // $repository = $this->entityManager->getRDBRepositoryByClass(Counter::class);

        // $numberOfCoundedEntities = $repository->count();

        $counter = $this->entityManager->getNewEntity('Counter');

        $counter->set('diskSize', 1.2);

        $counter->set('size', 7.2);

        $counter->set('numberOfRecords', 100);

        $counter->set('numberOfUsers', 8);

        $this->entityManager->saveEntity($counter);
    }
}

