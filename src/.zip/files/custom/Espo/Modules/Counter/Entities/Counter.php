<?php

namespace Espo\Modules\Counter\Entities;

use Espo\Core\ORM\Entity;

class Counter extends Entity
{
}